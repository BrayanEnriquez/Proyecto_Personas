﻿
using Microsoft.AspNetCore.Mvc;
using PersonasApi.Models;
using PersonasApi.Repositories;

namespace PersonasApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PersonasController : ControllerBase
{
    private readonly IPersonaRepository _repo;

    public PersonasController(IPersonaRepository repo) => _repo = repo;

    // Crear una persona
    [HttpPost]
    public ActionResult<PersonaReadDto> Create([FromBody] PersonaCreateDto dto)
    {
        // Si el dto no cumple, [ApiController] + FluentValidation devolverán 400 automáticamente.
        var persona = new Persona
        {
            Nombre = dto.Nombre.Trim(),
            Apellido = dto.Apellido.Trim(),
            Correo = dto.Correo.Trim(),
            Id = dto.Id.Trim()
        };

        _repo.Add(persona);
        var read = ToReadDto(persona);

        return CreatedAtAction(nameof(GetById), new { id = persona.Id }, read);
    }

    // Listar personas
    [HttpGet]
    public ActionResult<IEnumerable<PersonaReadDto>> GetAll()
        => Ok(_repo.GetAll().Select(ToReadDto));

    // Buscar por nombre
    [HttpGet("buscar")]
    public ActionResult<IEnumerable<PersonaReadDto>> SearchByNombre([FromQuery] string nombre)
        => Ok(_repo.SearchByNombre(nombre).Select(ToReadDto));

    // Obtener por Id (útil para CreatedAtAction)
    [HttpGet("{id}")]
    public ActionResult<PersonaReadDto> GetById(string id)
    {
        var persona = _repo.GetById(id);
        if (persona is null) return NotFound();
        return Ok(ToReadDto(persona));
    }

    // Actualizar una persona
    [HttpPut("{id}")]
    public IActionResult Update(string id, [FromBody] PersonaUpdateDto dto)
    {
        var existing = _repo.GetById(id);
        if (existing is null) return NotFound();

        existing.Nombre = dto.Nombre.Trim();
        existing.Apellido = dto.Apellido.Trim();
        existing.Correo = dto.Correo.Trim();
        existing.Id = dto.Id.Trim();

        _repo.Update(existing);
        return NoContent();
    }

    // Eliminar una persona
    [HttpDelete("{id}")]
    public IActionResult Delete(string id)
    {
        var ok = _repo.Delete(id);
        if (!ok) return NotFound();
        return NoContent();
    }

    private static PersonaReadDto ToReadDto(Persona p) => new()
    {
        Id = p.Id,
        Nombre = p.Nombre,
        Apellido = p.Apellido,
        Correo = p.Correo,
    };
}
