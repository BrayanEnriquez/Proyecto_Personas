﻿
namespace PersonasApi.Models;

public class PersonaUpdateDto
{
    public string Nombre { get; set; } = default!;
    public string Apellido { get; set; } = default!;
    public string Correo { get; set; } = default!;
    public string Id { get; set; } = default!;
}
