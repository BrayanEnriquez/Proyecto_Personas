﻿
using FluentValidation;
using PersonasApi.Models;

namespace PersonasApi.Validators;

public class PersonaUpdateValidator : AbstractValidator<PersonaUpdateDto>
{
    public PersonaUpdateValidator()
    {
        RuleFor(x => x.Nombre)
            .NotEmpty().MaximumLength(100);

        RuleFor(x => x.Apellido)
            .NotEmpty().MaximumLength(100);

        RuleFor(x => x.Correo)
            .NotEmpty().EmailAddress().MaximumLength(200);

        RuleFor(x => x.Id)
            .NotEmpty().Length(6, 20).Matches(@"^[A-Za-z0-9]+$");
    }
}
