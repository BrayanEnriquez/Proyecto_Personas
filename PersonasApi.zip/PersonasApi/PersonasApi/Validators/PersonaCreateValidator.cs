﻿
using FluentValidation;
using PersonasApi.Models;

namespace PersonasApi.Validators;

public class PersonaCreateValidator : AbstractValidator<PersonaCreateDto>
{
    public PersonaCreateValidator()
    {
        RuleFor(x => x.Nombre)
            .NotEmpty().WithMessage("Nombre es obligatorio")
            .MaximumLength(100);

        RuleFor(x => x.Apellido)
            .NotEmpty().WithMessage("Apellido es obligatorio")
            .MaximumLength(100);

        RuleFor(x => x.Correo)
            .NotEmpty().WithMessage("Correo es obligatorio")
            .EmailAddress().WithMessage("Correo no es válido")
            .MaximumLength(200);

        RuleFor(x => x.Id)
            .NotEmpty().WithMessage("Documento es obligatorio")
            .Length(6, 20).WithMessage("Documento debe tener entre 6 y 20 caracteres")
            .Matches(@"^[A-Za-z0-9]+$").WithMessage("Documento solo debe contener letras y/o números");
    }
}
