﻿
using PersonasApi.Models;

namespace PersonasApi.Repositories;

public interface IPersonaRepository
{
    IEnumerable<Persona> GetAll();
    IEnumerable<Persona> SearchByNombre(string nombre);
    Persona? GetById(string id);
    Persona Add(Persona persona);
    bool Update(Persona persona);
    bool Delete(string id);
}

