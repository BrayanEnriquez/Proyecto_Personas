﻿
using PersonasApi.Models;

namespace PersonasApi.Repositories;

public class InMemoryPersonaRepository : IPersonaRepository
{
    private readonly List<Persona> _items = new();
    private readonly object _lock = new();

    public IEnumerable<Persona> GetAll()
    {
        lock (_lock) return _items.ToList();
    }

    public IEnumerable<Persona> SearchByNombre(string nombre)
    {
        var term = nombre?.Trim() ?? string.Empty;
        lock (_lock)
        {
            return _items
                .Where(p => p.Nombre.Contains(term, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }
    }

    public Persona? GetById(string id)
    {
        lock (_lock) return _items.FirstOrDefault(p => p.Id == id);
    }

    public Persona Add(Persona persona)
    {
        lock (_lock)
        {
            _items.Add(persona);
            return persona;
        }
    }

    public bool Update(Persona persona)
    {
        lock (_lock)
        {
            var index = _items.FindIndex(p => p.Id == persona.Id);
            if (index == -1) return false;
            _items[index] = persona;
            return true;
        }
    }

    public bool Delete(string id)
    {
        lock (_lock)
        {
            var p = _items.FirstOrDefault(p => p.Id == id);
            if (p is null) return false;
            _items.Remove(p);
            return true;
        }
    }
}
