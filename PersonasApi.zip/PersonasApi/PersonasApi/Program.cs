
using FluentValidation;
using FluentValidation.AspNetCore;
using PersonasApi.Repositories;
using PersonasApi.Validators;

var builder = WebApplication.CreateBuilder(args);

// Controllers + Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Repositorio en memoria (Singleton)
builder.Services.AddSingleton<IPersonaRepository, InMemoryPersonaRepository>();

// FluentValidation
builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddValidatorsFromAssemblyContaining<PersonaCreateValidator>();

// ---------------------------------------------
// CORS: registrar la pol�tica ANTES de Build()
// ---------------------------------------------
builder.Services.AddCors(o =>
    o.AddDefaultPolicy(p =>
        p.WithOrigins(
            "http://localhost:5173",
            "http://localhost:5174"
        )
        .AllowAnyHeader()
        .AllowAnyMethod()
    // .AllowCredentials() // habil�talo solo si usas cookies/autenticaci�n (y NO uses AllowAnyOrigin)
    )
);

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// ---------------------------------------------
// Activar CORS ANTES de MapControllers()
// ---------------------------------------------
app.UseCors();

app.MapControllers();

app.Run();
